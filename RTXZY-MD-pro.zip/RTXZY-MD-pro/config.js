global.owner = ['6287760942535']  
global.mods = ['6287760942535'] 
global.prems = ['6287760942535']
global.nameowner = 'Yudd'
global.numberowner = '6287760942535' 
global.mail = 'support@yudd.eu.org' 
global.gc = 'https://chat.whatsapp.com/CP5mV2D9IO730HpBgkuyi'
global.instagram = 'https://instagram.com/Yudzsenpai'
global.wm = 'Yuda'
global.wait = '_*Tunggu sedang di proses...*_'
global.eror = '_*Server Error*_'
global.stiker_wait = '*⫹⫺ Stiker sedang dibuat...*'
global.packname = 'Made With'
global.author = 'Bot WhatsApp'
global.autobio = false // Set true untuk mengaktifkan autobio
global.maxwarn = '5' // Peringatan maksimum

//INI WAJIB DI ISI!//
global.btc = 'qpkn2uEH' 
//Daftar terlebih dahulu https://api.botcahx.eu.org

//INI OPTIONAL BOLEH DI ISI BOLEH JUGA ENGGA//
global.lann = 'RouMEYAa'
//Daftar https://api.betabotz.eu.org 

//jangan diganti!
global.APIs = {   
  btc: 'https://api.botcahx.eu.org',
  widipe: 'https://widipe.com'
}

//ini tidak di isi juga tidak apa-apa
global.APIKeys = { 
  'https://api.botcahx.eu.org': 'qpkn2uEH' 
}

let fs = require('fs')
let chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})
